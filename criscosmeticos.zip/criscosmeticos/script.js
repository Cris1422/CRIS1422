document.addEventListener("DOMContentLoaded", function () {
    const cart = document.getElementById("cart");
    const cartItems = document.getElementById("cartItems");
    const closeBtn = document.getElementById("closeBtn");
    const checkoutBtn = document.getElementById("checkoutBtn");
    const clearCartBtn = document.getElementById("clearCartBtn");
    const shoppingBagIcon = document.querySelector(".nav__icons");
    
    // Función para abrir el carrito
    function openCart() {
      cart.classList.add("show");
    }
    
    // Función para cerrar el carrito
    function closeCart() {
      cart.classList.remove("show");
    }
    

    // Función para agregar un producto al carrito
    function addToCart(name, price) {
      const item = document.createElement("li");
      item.innerHTML = `${name} - $${price}`;
      cartItems.appendChild(item);
      item.classList.add("cart-item");

      const itemInfo = document.createElement("div");
      itemInfo.classList.add("item-info");

      const itemName = document.createElement("span");
      itemInfo.appendChild(itemName);

      const itemPrice = document.createElement("span");
      itemPrice.textContent = `$${price.toFixed(2)}`;
      itemInfo.appendChild(itemPrice);

      const removeBtn = document.createElement("button");
      removeBtn.textContent = "Eliminar";
      removeBtn.classList.add("remove-btn");
      removeBtn.addEventListener("click", function () {
        item.remove();
      });

      // Calcular y mostrar el total del pago
      calculateTotal(price);

      itemInfo.appendChild(removeBtn);

      item.appendChild(itemInfo);

      cartItems.appendChild(item);
        }


    // Función para calcular el total del pago
    function calculateTotal(price) {
      const totalElement = document.getElementById("totalAmount");
      let total = parseFloat(totalElement.textContent.replace("$", ""));
      total += price;
      totalElement.textContent = `$${total.toFixed(2)}`;
    }    
    
    // Evento para abrir el carrito al hacer clic en el icono de shopping bag
    shoppingBagIcon.addEventListener("click", openCart);
    
    // Evento para cerrar el carrito al hacer clic en el botón de cerrar
    closeBtn.addEventListener("click", closeCart);
    
    // Obtener todos los botones "AGREGAR AL CARRITO"
    const addToCartBtns = document.querySelectorAll(".btn");
    
    // Iterar sobre cada botón y agregar un evento de clic
    addToCartBtns.forEach(function (btn) {
      btn.addEventListener("click", function () {
        const product = this.parentElement;
        const productName = product.querySelector("h4").textContent;
        const productPrice = product.querySelector("p").textContent;
        const price = parseFloat(productPrice.replace("$", ""));
        addToCart(productName, price);
      });
    });
  });